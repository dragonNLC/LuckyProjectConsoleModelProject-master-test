package com.dragon.lucky.command28;

public class CollectBean {

    public String tag;
    public int count;

    public CollectBean() {
    }

    public CollectBean(String tag, int count) {
        this.tag = tag;
        this.count = count;
    }
}
