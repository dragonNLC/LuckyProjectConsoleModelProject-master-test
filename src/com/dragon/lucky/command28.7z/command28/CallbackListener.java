package com.dragon.lucky.command28;


import com.dragon.lucky.command21.OnceGenerateBean;

public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
