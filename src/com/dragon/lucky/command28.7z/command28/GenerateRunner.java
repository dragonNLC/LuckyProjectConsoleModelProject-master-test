package com.dragon.lucky.command28;

import com.dragon.lucky.utils.FileReadHelper;
import com.dragon.lucky.utils.Log;
import com.dragon.lucky.utils.Utils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class GenerateRunner {

    private static GenerateRunner sInstance;


    private GenerateRunner() {

    }

    public static GenerateRunner getInstance() {
        if (sInstance == null) {
            synchronized (GenerateRunner.class) {
                if (sInstance == null) {
                    sInstance = new GenerateRunner();
                }
            }
        }
        return sInstance;
    }

    public void run(CommandBean command) throws IOException {
        if (!FileReadHelper.checkFileExists(command.getInputPath())) {
            Log.i("预加载文件不存在");
            return;
        }
        Map<String, Integer> collect = new HashMap<>();

        List<String> inputData = FileReadHelper.readFile(command.getInputPath());

        for (int k = 0; k < inputData.size(); k++) {
            List<String> inputData2 = FileReadHelper.readFile(inputData.get(k));
            List<NumberDataBean> previewResult = new ArrayList<>();
            for (int i = 0; i < inputData2.size(); i++) {
                String d = inputData2.get(i);
                if (!d.contains("[") || !d.contains("]")) {
                    continue;
                }
                String line = "";
                if (d.contains("],[")) {
                    String[] content = d.split("],\\[");
                    line = content[0].replace("[", "").replace("]", "");
                } else {
                    line = d.replace("[", "").replace("]", "");
                }
                String[] splitLine = line.split(", ");
                if (splitLine != null && splitLine.length > 0) {
//                    Log.i("line = " + splitLine.length);
                    byte[] numbers = new byte[splitLine.length];
                    for (int j = 0; j < splitLine.length; j++) {
                        if (Utils.isNumeric(splitLine[j])) {
                            numbers[j] = Byte.parseByte(splitLine[j]);
                        }
                    }
                    previewResult.add(new NumberDataBean(numbers));
                }
            }
            for (int i = 0; i < previewResult.size(); i++) {
                NumberDataBean ndb = previewResult.get(i);
                if (!collect.containsKey(Arrays.toString(ndb.getData()))) {
                    collect.put(Arrays.toString(ndb.getData()), 0);
                }
                collect.put(Arrays.toString(ndb.getData()), collect.get(Arrays.toString(ndb.getData())) + 1);
            }
            Log.i("path = " + inputData.get(k));
        }

        List<CollectBean> collectBeans = new ArrayList<>();
        for (String key :
                collect.keySet()) {
            collectBeans.add(new CollectBean(key, collect.get(key)));
        }

        collectBeans.sort(new Comparator<CollectBean>() {
            @Override
            public int compare(CollectBean o1, CollectBean o2) {
                return Integer.compare(o2.count, o1.count);
            }
        });

        FileReadHelper.writeToFileForRun28(command.getOutputPath(), collectBeans);
        Log.i("输出完成！");
    }

}
