package com.dragon.lucky.command3;

import com.dragon.lucky.command21.PartitionBean;

import java.util.Map;

public class OnceGenerateBean {

    private String title;
    private int size;
    private int z5;
    private int z4;
    private int z3;
    private int z2;

    public OnceGenerateBean() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getZ5() {
        return z5;
    }

    public void setZ5(int z5) {
        this.z5 = z5;
    }

    public int getZ4() {
        return z4;
    }

    public void setZ4(int z4) {
        this.z4 = z4;
    }

    public int getZ3() {
        return z3;
    }

    public void setZ3(int z3) {
        this.z3 = z3;
    }

    public int getZ2() {
        return z2;
    }

    public void setZ2(int z2) {
        this.z2 = z2;
    }
}
