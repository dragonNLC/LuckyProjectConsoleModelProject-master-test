package com.dragon.lucky.command3;


public interface CallbackListener {

    void onCompile(/*OnceGenerateBean onceGenerateData*/);
}
