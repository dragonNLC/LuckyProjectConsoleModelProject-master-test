package com.dragon.lucky.command15;


public interface CallbackListener {

    void onCompile();
}
