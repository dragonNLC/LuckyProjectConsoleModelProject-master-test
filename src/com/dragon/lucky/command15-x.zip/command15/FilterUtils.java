package com.dragon.lucky.command15;

import com.dragon.lucky.bean.BaseControlNumberBean;
import com.dragon.lucky.bean.ResultBean;
import com.dragon.lucky.utils.Log;

import java.util.*;

public class FilterUtils {

    public static int FILTER_COUNT = 0;//记录方法运行次数
    public static int FILTER_COUNT_SIZE = 0;

    //取得数据然后取并集
    public static List<NumberDataBean> filterResultBean(List<NumberDataBean> base, List<LineBean> filter) {
        Iterator<NumberDataBean> numberData = base.iterator();
        List<NumberDataBean> result = new ArrayList<>();
        int count = 0;
        while (numberData.hasNext()) {
            NumberDataBean numberDataBean = numberData.next();
            byte[] numberDataBytes = numberDataBean.getData();
            boolean remove = false;
            laeblPoint:
            for (int m = 0; m < filter.size(); m++) {
                LineBean lineBean = filter.get(m);
                for (int k = 0; k < lineBean.getData().size(); k++) {
                    NumberBean numberBean = lineBean.getData().get(k);
                    int containCount = 0;
                    for (int j = 0; j < numberDataBytes.length; j++) {
                        for (int l = 0; l < numberBean.getData().length; l++) {
                            if (numberDataBytes[j] == numberBean.getData()[l]) {
                                containCount++;
                            }
                        }
                    }
                    if (containCount > numberBean.getGenerateSize()) {
                        count++;
                        Log.i("containCount = " + containCount + "   " + numberBean.getGenerateSize() + "   " + count);
//                        numberData.remove();
                        remove = true;
                        break laeblPoint;
                    }
                }
            }
            if (!remove) {
                result.add(numberDataBean);
            }
        }
        return result;
    }

    //取得数据然后取并集
    public static List<NumberDataBean> filterResultBean2(List<NumberDataBean> base, List<NumberBean> filter) {
        Iterator<NumberDataBean> numberData = base.iterator();
        int count = 0;
        while (numberData.hasNext()) {
            NumberDataBean numberDataBean = numberData.next();
            byte[] numberDataBytes = numberDataBean.getData();
            laeblPoint:
            for (int k = 0; k < filter.size(); k++) {
                NumberBean numberBean = filter.get(k);
                if (numberBean.getData() == null) {
//                        Log.i("continue");
                    continue;
                } else {
//                        Log.i("not continue");
                }
                int containCount = 0;
                for (int j = 0; j < numberDataBytes.length; j++) {
                    for (int l = 0; l < numberBean.getData().length; l++) {
                        if (numberDataBytes[j] == numberBean.getData()[l]) {
                            containCount++;
                        }
                    }
                }
                if (containCount > numberBean.getGenerateSize()) {
                    count++;
//                        Log.i("containCount = " + containCount + "   " + numberBean.getGenerateSize() + "   " + count);
                    numberData.remove();
                    break laeblPoint;
                }
            }
        }
        return base;
    }

    //取得数据然后取并集
    /*public static List<NumberDataBean> filterResultBean2(List<NumberDataBean> base, List<NumberBean> filter) {
        Iterator<NumberDataBean> numberData = base.iterator();
        List<NumberDataBean> result = new ArrayList<>();
        int count = 0;
        while (numberData.hasNext()) {
            NumberDataBean numberDataBean = numberData.next();
            byte[] numberDataBytes = numberDataBean.getData();
            boolean remove = false;
            for (int k = 0; k < filter.size(); k++) {
                NumberBean numberBean = filter.get(k);
                if (numberBean.getData() == null) {
                    continue;
                }
                int containCount = 0;
                for (int j = 0; j < numberDataBytes.length; j++) {
                    for (int l = 0; l < numberBean.getData().length; l++) {
                        if (numberDataBytes[j] == numberBean.getData()[l]) {
//                            Log.i("numberDataBytes[j] = " + numberDataBytes[j] + "   " + numberBean.getData()[l] + "   " + j);
                            containCount++;
                        }
                    }
                }
                if (containCount > numberBean.getGenerateSize()) {
//                    Log.i("numberDataBean = " + Arrays.toString(numberDataBean.getData()));
                    count++;
//                        Log.i("containCount = " + containCount + "   " + numberBean.getGenerateSize() + "   " + count);
//                    numberData.remove();
                    remove = true;
                    break;
                }
            }
            if (!remove) {
                result.add(numberDataBean);
            }
        }
        base.clear();
        System.gc();
        return result;
    }*/

}
