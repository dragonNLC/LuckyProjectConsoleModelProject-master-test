package com.dragon.lucky.command16;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
