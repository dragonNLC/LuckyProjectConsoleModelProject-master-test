package com.dragon.lucky.command18;


public interface CallbackListener {

    void onCompile();
}
