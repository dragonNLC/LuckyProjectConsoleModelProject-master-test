package com.dragon.lucky.spider;

import com.dragon.lucky.spider.utils.JsoupHelper;

public class Main3 {

    public static void main(String[] args) {
        JsoupHelper.doConnect10();
    }

}
