package com.dragon.lucky.command9;


public interface CallbackListener {

    void onCompile();

}
