package com.dragon.lucky.command9;

public class CollectBean {

    private Byte b;
    private int count;

    public CollectBean() {
    }

    public CollectBean(Byte b, int count) {
        this.b = b;
        this.count = count;
    }

    public Byte getB() {
        return b;
    }

    public void setB(Byte b) {
        this.b = b;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

}

