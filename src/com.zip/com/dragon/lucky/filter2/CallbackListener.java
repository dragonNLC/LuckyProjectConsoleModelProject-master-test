package com.dragon.lucky.filter2;


public interface CallbackListener {

    void onCompile();
}
