package com.dragon.lucky.command8a;


public interface CallbackListener {

    void onCompile();

}
