package com.dragon.lucky.command8a;

public class ExistsBean {

    private Byte notExistsByte;

    public ExistsBean() {
    }

    public Byte getNotExistsByte() {
        return notExistsByte;
    }

    public void setNotExistsByte(Byte notExistsByte) {
        this.notExistsByte = notExistsByte;
    }
}
