package com.dragon.lucky.command8;


public interface CallbackListener {

    void onCompile();

}
