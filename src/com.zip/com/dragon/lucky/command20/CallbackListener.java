package com.dragon.lucky.command20;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
