package com.dragon.lucky.command24;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
