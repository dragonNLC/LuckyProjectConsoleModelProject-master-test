package com.dragon.lucky.command24;

public class CollectionData {

    public String key;
    public Integer count;

    public CollectionData(String key, Integer count) {
        this.key = key;
        this.count = count;
    }
}
