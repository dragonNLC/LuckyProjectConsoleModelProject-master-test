package com.dragon.lucky.command14;


public interface CallbackListener {

    void onCompile();
}
