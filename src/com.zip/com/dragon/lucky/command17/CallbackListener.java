package com.dragon.lucky.command17;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
