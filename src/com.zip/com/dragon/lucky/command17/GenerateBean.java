package com.dragon.lucky.command17;

import com.dragon.lucky.bean.ResultBean;

import java.util.List;

public class GenerateBean {

    private CollectionBean data7Place;
    private CollectionBean data6Place;
    private CollectionBean data5Place;
    private int generateSize;

    public GenerateBean() {
    }

    public CollectionBean getData7Place() {
        return data7Place;
    }

    public void setData7Place(CollectionBean data7Place) {
        this.data7Place = data7Place;
    }

    public CollectionBean getData6Place() {
        return data6Place;
    }

    public void setData6Place(CollectionBean data6Place) {
        this.data6Place = data6Place;
    }

    public CollectionBean getData5Place() {
        return data5Place;
    }

    public void setData5Place(CollectionBean data5Place) {
        this.data5Place = data5Place;
    }

    public int getGenerateSize() {
        return generateSize;
    }

    public void setGenerateSize(int generateSize) {
        this.generateSize = generateSize;
    }
}
