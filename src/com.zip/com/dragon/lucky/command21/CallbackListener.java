package com.dragon.lucky.command21;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
