package com.dragon.lucky.command21;

public class PartitionBean {

    private int count;
    private int z1;
    private int z2;
    private int z3;
    private int z4;
    private int z5;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getZ1() {
        return z1;
    }

    public void setZ1(int z1) {
        this.z1 = z1;
    }

    public int getZ2() {
        return z2;
    }

    public void setZ2(int z2) {
        this.z2 = z2;
    }

    public int getZ3() {
        return z3;
    }

    public void setZ3(int z3) {
        this.z3 = z3;
    }

    public int getZ4() {
        return z4;
    }

    public void setZ4(int z4) {
        this.z4 = z4;
    }

    public int getZ5() {
        return z5;
    }

    public void setZ5(int z5) {
        this.z5 = z5;
    }
}
