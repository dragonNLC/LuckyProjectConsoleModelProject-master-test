package com.dragon.lucky.bean.cut;

import com.dragon.lucky.bean.ResultBean;
import com.dragon.lucky.bean.ResultMergeBean;

import java.util.List;

public class CutResultBean2 {

    public int start;
    public int end;

    public CutResultBean2(int start, int end) {
        this.start = start;
        this.end = end;
    }

}
