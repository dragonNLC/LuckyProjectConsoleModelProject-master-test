package com.dragon.lucky.bean.cut;

import com.dragon.lucky.bean.ResultBean;

import java.util.List;

public class CutResultBean {

    public List<ResultBean> data;

    public CutResultBean(List<ResultBean> data) {
        this.data = data;
    }

}
