package com.dragon.lucky.bean;

public class ItemBean {

    private int[] data;

    public ItemBean() {
    }

    public ItemBean(int[] data) {
        this.data = data;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }
}
