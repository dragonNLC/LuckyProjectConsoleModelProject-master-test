package com.dragon.lucky.command11;


public interface CallbackListener {

    void onCompile();
}
