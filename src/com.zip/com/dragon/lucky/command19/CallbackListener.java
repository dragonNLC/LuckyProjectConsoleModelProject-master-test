package com.dragon.lucky.command19;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
