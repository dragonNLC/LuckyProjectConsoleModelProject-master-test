package com.dragon.lucky.command13;


public interface CallbackListener {

    void onCompile();
}
