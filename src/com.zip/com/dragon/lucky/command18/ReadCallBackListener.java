package com.dragon.lucky.command18;

import java.util.List;

public interface ReadCallBackListener {

    void onResultGroup(List<String> contents);

}
