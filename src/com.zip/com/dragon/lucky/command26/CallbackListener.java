package com.dragon.lucky.command26;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateBean);
}
