package com.dragon.lucky.command25;


public interface CallbackListener {

    void onCompile(OnceGenerateBean onceGenerateData);
}
