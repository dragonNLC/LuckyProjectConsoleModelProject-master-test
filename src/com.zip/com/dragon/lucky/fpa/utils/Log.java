package com.dragon.lucky.fpa.utils;

public class Log {

    public static void e(String tag, String content) {
        System.out.println(tag + "   " + content);
    }

    public static void i(String content) {
        System.out.println(content);
    }

}
