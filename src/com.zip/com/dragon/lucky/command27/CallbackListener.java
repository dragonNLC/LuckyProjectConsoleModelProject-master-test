package com.dragon.lucky.command27;


public interface CallbackListener {

    void onCompile();
}
