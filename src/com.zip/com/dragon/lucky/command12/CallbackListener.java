package com.dragon.lucky.command12;


public interface CallbackListener {

    void onCompile();
}
