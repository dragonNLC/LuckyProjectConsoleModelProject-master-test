package com.dragon.lucky.filter;


public interface CallbackListener {

    void onCompile();
}
