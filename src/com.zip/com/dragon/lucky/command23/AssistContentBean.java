package com.dragon.lucky.command23;

public class AssistContentBean {

    public String title;
    public int size;
    public int z1;
    public int z2;
    public int z3;
    public int z4;
    public int z5;

    public AssistContentBean() {
    }

    public AssistContentBean(String title, int size, int z1, int z2, int z3, int z4, int z5) {
        this.title = title;
        this.size = size;
        this.z1 = z1;
        this.z2 = z2;
        this.z3 = z3;
        this.z4 = z4;
        this.z5 = z5;
    }
}
