package com.dragon.lucky.command7;


public interface CallbackListener {

    void onCompile();

}
