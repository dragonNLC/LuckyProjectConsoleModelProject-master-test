package com.dragon.lucky.command15;


public class NumberDataBean {

    private byte[] data;

    public NumberDataBean() {
    }

    public NumberDataBean(byte[] data) {
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}


