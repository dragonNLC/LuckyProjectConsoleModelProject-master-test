package com.dragon.lucky.command10;


public interface CallbackListener {

    void onCompile();
}
